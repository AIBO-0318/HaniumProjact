# vision/gaze.py

import cv2
import mediapipe as mp

mp_face = mp.solutions.face_mesh
face_mesh = mp_face.FaceMesh(refine_landmarks=True)

cap = cv2.VideoCapture(0)

def check_gaze():
    ret, frame = cap.read()
    if not ret:
        return "UNKNOWN", frame

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = face_mesh.process(rgb)

    direction = "UNKNOWN"

    if result.multi_face_landmarks:
        for face_landmarks in result.multi_face_landmarks:

            left_eye_left = face_landmarks.landmark[33]
            left_eye_right = face_landmarks.landmark[133]
            left_iris = face_landmarks.landmark[468]

            right_eye_left = face_landmarks.landmark[362]
            right_eye_right = face_landmarks.landmark[263]
            right_iris = face_landmarks.landmark[473]

            left_ratio = (left_iris.x - left_eye_left.x) / (left_eye_right.x - left_eye_left.x)
            right_ratio = (right_iris.x - right_eye_left.x) / (right_eye_right.x - right_eye_left.x)

            gaze_ratio = (left_ratio + right_ratio) / 2

            if gaze_ratio < 0.4:
                direction = "LEFT"
            elif gaze_ratio > 0.6:
                direction = "RIGHT"
            else:
                direction = "CENTER"

    return direction, frame
