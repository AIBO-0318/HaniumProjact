# main.py

import cv2
from vision.gaze import check_gaze

while True:
    direction, frame = check_gaze()

    if direction == "CENTER":
        text = "LOOKING"
        color = (0, 255, 0)
    elif direction == "LEFT":
        text = "LOOKING LEFT"
        color = (255, 0, 0)
    elif direction == "RIGHT":
        text = "LOOKING RIGHT"
        color = (0, 0, 255)
    else:
        text = "UNKNOWN"
        color = (255, 255, 255)

    print(text)

    cv2.putText(frame, text, (50,50),
                cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

    cv2.imshow("Gaze", frame)

    if cv2.waitKey(1) == 27:
        break

cv2.destroyAllWindows()
