import tkinter as tk
from tkinter import messagebox, simpledialog
import cv2
import time

# 너 기존 코드 (그대로 사용)
from vision.gaze import check_gaze
from control.video_control import pause_video

class StudyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("AI 학습 관리 시스템")
        self.root.geometry("400x300")

        # 상태 변수
        self.not_looking_start = None
        self.threshold = 3  # 기본 3초

        self.create_main_menu()

    # 메인 메뉴
    def create_main_menu(self):
        self.clear_window()

        tk.Label(self.root, text="AI 학습 관리 시스템", font=("Arial", 16)).pack(pady=20)

        tk.Button(self.root, text="학습 시작", width=20, command=self.open_study).pack(pady=5)
        tk.Button(self.root, text="설정", width=20, command=self.open_settings).pack(pady=5)
        tk.Button(self.root, text="종료", width=20, command=self.root.quit).pack(pady=5)

    # 학습 화면
    def open_study(self):
        self.clear_window()

        self.status_label = tk.Label(self.root, text="집중 상태: 집중", font=("Arial", 12))
        self.status_label.pack(pady=10)

        tk.Button(self.root, text="AI 질문", command=self.ask_ai).pack(pady=5)
        tk.Button(self.root, text="종료", command=self.end_study).pack(pady=5)

        # 카메라 시작
        self.cap = cv2.VideoCapture(0)

        self.update_gaze()

    # 핵심 로직 (시선 + 3초 정지)
    def update_gaze(self):
        direction, frame = check_gaze()

        current_time = time.time()

        if direction == "not_looking":
            if self.not_looking_start is None:
                self.not_looking_start = current_time

            elif current_time - self.not_looking_start >= self.threshold:
                self.status_label.config(text="집중 상태: 이탈 (영상 정지)")
                pause_video()  # 🔥 영상 정지
        else:
            self.not_looking_start = None
            self.status_label.config(text="집중 상태: 집중")

        # 카메라 화면 출력
        cv2.imshow("Camera", frame)
        cv2.waitKey(1)

        # 반복 실행 (GUI 안멈춤)
        self.root.after(100, self.update_gaze)

    # 설정
    def open_settings(self):
        self.clear_window()

        tk.Label(self.root, text="설정", font=("Arial", 16)).pack(pady=10)

        tk.Label(self.root, text="시선 이탈 기준(초)").pack()
        self.gaze_entry = tk.Entry(self.root)
        self.gaze_entry.insert(0, str(self.threshold))
        self.gaze_entry.pack()

        tk.Button(self.root, text="저장", command=self.save_settings).pack(pady=10)
        tk.Button(self.root, text="뒤로가기", command=self.create_main_menu).pack()

    def save_settings(self):
        try:
            self.threshold = int(self.gaze_entry.get())
            messagebox.showinfo("저장", f"시선 기준: {self.threshold}초")
            self.create_main_menu()
        except:
            messagebox.showerror("오류", "숫자를 입력하세요")

    # AI 질문
    def ask_ai(self):
        question = simpledialog.askstring("AI 질문", "질문 입력:")
        if question:
            messagebox.showinfo("AI 답변", f"{question}에 대한 답변입니다.")

    # 종료
    def end_study(self):
        try:
            cv2.destroyAllWindows()
        except:
            pass

        messagebox.showinfo("종료", "학습 종료")
        self.create_main_menu()

    # 화면 초기화
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()


# 실행
root = tk.Tk()
app = StudyApp(root)
root.mainloop()
