#video_control.py

import pyautogui
import time

def pause_video():
    print("멈춤 실행됨")
    time.sleep(0.2)
    pyautogui.press('space')
    