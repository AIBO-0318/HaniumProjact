# main.py

import cv2
from vision.gaze import check_gaze
from control.video_control import pause_video
from utils.timer import start_timer, stop_timer

start_timer()

not_looking_count = 0

while True:
    direction, frame = check_gaze()

    # 고개 돌리면 count 증가
    if direction != "CENTER":
        not_looking_count += 1
    else:
        not_looking_count = 0

    # 일정 이상 안 보면 멈춤
    if not_looking_count > 5:
        pause_video()
        not_looking_count = 0  #초기화 반복 가능

    # 텍스트 표시
    if direction == "CENTER":
        text = "LOOKING"
        color = (0, 255, 0)
    else:
        text = "NOT LOOKING"
        color = (0, 0, 255)

    cv2.putText(frame, text, (50, 50),
                cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

    if cv2.waitKey(1) == 27:
        break

    cv2.imshow("Gaze", frame)

stop_timer()
cv2.destroyAllWindows()
