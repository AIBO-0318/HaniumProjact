#timer.py

import time
from datetime import datetime
import json
import os

start_time = None

def start_timer():
    global start_time
    start_time = time.time()

def stop_timer():
    global start_time
    if start_time is None:
        return

    elapsed = time.time() - start_time
    save_time(elapsed)
    start_time = None

def save_time(elapsed):
    today = datetime.now().strftime("%Y-%m-%d")

    data = {}
    if os.path.exists("study_time.json"):
        with open("study_time.json", "r") as f:
            data = json.load(f)

    data[today] = data.get(today, 0) + int(elapsed)

    with open("study_time.json", "w") as f:
        json.dump(data, f, indent=4)

    print(f"오늘 학습 시간: {data[today]}초")